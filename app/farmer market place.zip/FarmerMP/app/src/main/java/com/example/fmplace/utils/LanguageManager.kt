package com.example.fmplace.utils

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.content.res.Resources
import android.os.Build
import android.content.Intent
import java.util.Locale

object LanguageManager {
    private const val PREFS_NAME = "app_prefs"
    private const val KEY_LANGUAGE = "language_code"

    private fun getSharedPreferences(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun setAppLanguage(context: Context, languageCode: String) {
        // Update the app's locale
        val locale = when (languageCode) {
            "mr" -> Locale("mr", "IN")
            "hi" -> Locale("hi", "IN")
            "en" -> Locale("en", "US")
            else -> Locale("en", "US")
        }

        // Update the app's locale
        Locale.setDefault(locale)
        
        // Update the configuration
        val resources = context.resources
        val configuration = Configuration(resources.configuration)
        configuration.setLocale(locale)
        
        // Update the resources
        resources.updateConfiguration(configuration, resources.displayMetrics)
        
        // Save the language preference
        getSharedPreferences(context)
            .edit()
            .putString(KEY_LANGUAGE, languageCode)
            .apply()

        // Restart the app to apply changes
        context.packageManager.getLaunchIntentForPackage(context.packageName)?.let { intent ->
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }
    }

    fun getSavedLanguage(context: Context): String {
        return getSharedPreferences(context)
            .getString(KEY_LANGUAGE, "en") ?: "en"
    }

    fun applySavedLanguage(context: Context) {
        val languageCode = getSavedLanguage(context)
        setAppLanguage(context, languageCode)
    }

    fun updateActivityConfiguration(context: Context) {
        val languageCode = getSavedLanguage(context)
        val locale = when (languageCode) {
            "mr" -> Locale("mr", "IN")
            "hi" -> Locale("hi", "IN")
            "en" -> Locale("en", "US")
            else -> Locale("en", "US")
        }

        val resources = context.resources
        val configuration = Configuration(resources.configuration)
        configuration.setLocale(locale)
        resources.updateConfiguration(configuration, resources.displayMetrics)
    }

    fun getLanguageDisplayName(code: String): String {
        return when (code) {
            "mr" -> "मराठी"
            "hi" -> "हिंदी"
            "en" -> "English"
            else -> "English"
        }
    }

    fun getLanguageCodeFromDisplayName(displayName: String): String {
        return when (displayName) {
            "मराठी" -> "mr"
            "हिंदी" -> "hi"
            "English" -> "en"
            else -> "en"
        }
    }
}
