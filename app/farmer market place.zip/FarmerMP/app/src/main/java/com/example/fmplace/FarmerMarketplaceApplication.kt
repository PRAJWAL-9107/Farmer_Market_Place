package com.example.fmplace

import android.app.Application
import com.example.fmplace.firebase.FirebaseManager
import com.example.fmplace.storage.CloudinaryRepository

/**
 * Application class for the Farmer Marketplace app
 * Initializes Firebase and other app-wide components
 */
class FarmerMarketplaceApplication : Application() {
    
    override fun onCreate() {
        super.onCreate()
        
        // Initialize Firebase
        FirebaseManager.initialize(this)
        
        // Initialize Cloudinary
        CloudinaryRepository.init(this)
    }
}
