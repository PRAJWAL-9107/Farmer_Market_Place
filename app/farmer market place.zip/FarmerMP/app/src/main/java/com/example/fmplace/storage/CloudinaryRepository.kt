package com.example.fmplace.storage

import android.content.Context
import android.net.Uri
import android.util.Log
import com.cloudinary.android.MediaManager
import com.cloudinary.android.callback.ErrorInfo
import com.cloudinary.android.callback.UploadCallback
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlin.coroutines.resume

/**
 * Repository for handling image uploads to Cloudinary
 */
class CloudinaryRepository(private val context: Context) {
    private val TAG = "CloudinaryRepository"
    
    /**
     * Initialize Cloudinary with your configuration
     * Call this method from your Application class
     */
    companion object {
        private var initialized = false
        
        fun init(context: Context) {
            if (!initialized) {
                try {
                    // Configure Cloudinary
                    val config = mapOf(
                        "cloud_name" to "dodhcgctg",
                        "api_key" to "569876324763573",
                        "api_secret" to "VDK9dXvbxhAPhB6WtEaHbbzCOPg"
                    )
                    
                    MediaManager.init(context, config)
                    initialized = true
                    Log.d("CloudinaryRepository", "Cloudinary initialized successfully")
                } catch (e: Exception) {
                    Log.e("CloudinaryRepository", "Error initializing Cloudinary", e)
                }
            }
        }
    }
    
    /**
     * Upload an image to Cloudinary
     * @param imageUri The URI of the image to upload
     * @return Result containing the URL of the uploaded image
     */
    suspend fun uploadImage(imageUri: Uri): Result<String> {
        return withContext(Dispatchers.IO) {
            try {
                // Create a temporary file from the URI
                val inputStream = context.contentResolver.openInputStream(imageUri)
                    ?: return@withContext Result.failure(Exception("Failed to open input stream"))
                
                val tempFile = File(context.cacheDir, "temp_${UUID.randomUUID()}.jpg")
                FileOutputStream(tempFile).use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
                inputStream.close()
                
                // Upload the file to Cloudinary
                val requestId = UUID.randomUUID().toString()
                
                suspendCancellableCoroutine { continuation ->
                    val uploadRequest = MediaManager.get().upload(tempFile.absolutePath)
                        // Use signed upload instead of unsigned preset
                        .option("folder", "product_images")
                        .callback(object : UploadCallback {
                            override fun onStart(requestId: String) {
                                Log.d(TAG, "Upload started: $requestId")
                            }
                            
                            override fun onProgress(requestId: String, bytes: Long, totalBytes: Long) {
                                val progress = (bytes * 100) / totalBytes
                                Log.d(TAG, "Upload progress: $progress%")
                            }
                            
                            override fun onSuccess(requestId: String, resultData: Map<*, *>?) {
                                val url = resultData?.get("secure_url") as? String
                                if (url != null) {
                                    Log.d(TAG, "Upload successful: $url")
                                    tempFile.delete() // Clean up temp file
                                    continuation.resume(Result.success(url))
                                } else {
                                    Log.e(TAG, "Upload successful but URL is null")
                                    tempFile.delete() // Clean up temp file
                                    continuation.resume(Result.failure(Exception("Upload URL is null")))
                                }
                            }
                            
                            override fun onError(requestId: String, error: ErrorInfo) {
                                Log.e(TAG, "Upload error: ${error.description}")
                                tempFile.delete() // Clean up temp file
                                continuation.resume(Result.failure(Exception(error.description)))
                            }
                            
                            override fun onReschedule(requestId: String, error: ErrorInfo) {
                                Log.d(TAG, "Upload rescheduled: ${error.description}")
                            }
                        })
                        .dispatch()
                    
                    continuation.invokeOnCancellation {
                        MediaManager.get().cancelRequest(requestId)
                        tempFile.delete() // Clean up temp file
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error uploading image", e)
                Result.failure(e)
            }
        }
    }
    
    /**
     * Delete an image from Cloudinary
     * Note: This requires server-side code or a signed API call with your API secret
     * For security reasons, you should implement this on your backend
     */
    suspend fun deleteImage(imageUrl: String): Result<Unit> {
        // This would require server-side implementation or a secure API call
        // Not recommended to implement directly in the app
        return Result.failure(Exception("Image deletion should be implemented on the server side"))
    }
}
