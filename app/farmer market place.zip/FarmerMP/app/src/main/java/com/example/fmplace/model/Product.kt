package com.example.fmplace.model

/**
 * Product data class representing products added by farmers
 */
data class Product(
    val id: String = "",
    val name: String = "",
    val category: ProductCategory = ProductCategory.OTHER,
    val price: Double = 0.0,
    val unit: String = "kg",
    val description: String = "",
    val imageUrl: String = "",
    val sellerId: String = "",
    val sellerContact: String = "",
    val sellerName: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Enum class representing product categories
 */
enum class ProductCategory {
    VEGETABLES, FRUITS, DAIRY, GRAINS, OTHER
}
