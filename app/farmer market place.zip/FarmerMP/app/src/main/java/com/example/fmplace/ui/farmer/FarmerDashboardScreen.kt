package com.example.fmplace.ui.farmer

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material3.Button
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.fmplace.firebase.AuthRepository
import com.example.fmplace.model.User
import com.example.fmplace.ui.common.DrawerMenu
import com.example.fmplace.utils.Utils
import kotlinx.coroutines.launch

/**
 * Farmer Dashboard Screen - Main screen for farmers
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FarmerDashboardScreen(navController: NavController) {
    val authRepository = remember { AuthRepository() }
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    
    var user by remember { mutableStateOf<User?>(null) }
    
    // Get current user data
    LaunchedEffect(Unit) {
        val currentUser = authRepository.getCurrentUser()
        if (currentUser == null) {
            // Not logged in, navigate to welcome screen
            navController.navigate("welcome") {
                popUpTo("welcome") { inclusive = true }
            }
            return@LaunchedEffect
        }
        
        // Get user data from Firestore
        val result = authRepository.getUserData(currentUser.uid)
        if (result.isSuccess) {
            user = result.getOrNull()
        } else {
            Utils.showToast(context, "Failed to load user data")
        }
    }
    
    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerMenu(
                drawerState = drawerState,
                currentUser = user,
                navController = navController,
                onLogout = {
                    authRepository.logout()
                    navController.navigate("welcome") {
                        popUpTo("welcome") { inclusive = true }
                    }
                }
            )
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Farmer Dashboard") },
                    navigationIcon = {
                        IconButton(onClick = {
                            coroutineScope.launch {
                                drawerState.open()
                            }
                        }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu")
                        }
                    },
                    actions = {
                        IconButton(onClick = {
                            navController.navigate("support")
                        }) {
                            Icon(Icons.Filled.Info, contentDescription = "Support")
                        }
                    }
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Welcome message
                user?.let {
                    Text(
                        text = "Welcome, ${it.name}",
                        style = MaterialTheme.typography.headlineMedium
                    )
                    
                    Spacer(modifier = Modifier.height(32.dp))
                }
                
                // Add Product Button
                Button(
                    onClick = { navController.navigate("add_product") },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.Add, contentDescription = "Add Product")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Add New Product")
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // My Products Button
                Button(
                    onClick = { navController.navigate("my_products") },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.List, contentDescription = "My Products")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("My Products")
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Browse Products Button (Added for common functionality)
                Button(
                    onClick = { navController.navigate("buyer_home") },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.List, contentDescription = "Browse Products")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Browse Products")
                }
            }
        }
    }
}
