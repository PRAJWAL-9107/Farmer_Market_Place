package com.example.fmplace

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.fmplace.ui.auth.LoginScreen
import com.example.fmplace.ui.auth.RegisterScreen
import com.example.fmplace.ui.auth.WelcomeScreen
import com.example.fmplace.ui.buyer.BuyerHomeScreen
import com.example.fmplace.ui.buyer.ProductDetailsScreen
import com.example.fmplace.ui.farmer.AddProductScreen
import com.example.fmplace.ui.farmer.FarmerDashboardScreen
import com.example.fmplace.ui.farmer.MyProductsScreen
import com.example.fmplace.ui.profile.ProfileScreen
import com.example.fmplace.ui.support.SupportScreen
import com.example.fmplace.ui.SettingsScreen
import com.example.fmplace.ui.theme.FarmerMarketPlaceTheme
import com.example.fmplace.utils.LanguageManager
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        LanguageManager.applySavedLanguage(this)
        
        enableEdgeToEdge()
        setContent {
            FarmerMarketPlaceTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    FarmerMarketplaceApp()
                }
            }
        }
    }

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        
        val languageCode = LanguageManager.getSavedLanguage(base)
        val locale = when (languageCode) {
            "mr" -> Locale("mr", "IN")
            "hi" -> Locale("hi", "IN")
            "en" -> Locale("en", "US")
            else -> Locale("en", "US")
        }
        
        Locale.setDefault(locale)
        val config = Configuration(base.resources.configuration)
        config.setLocale(locale)
        
        base.createConfigurationContext(config)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        LanguageManager.applySavedLanguage(this)
    }
}

@Composable
fun FarmerMarketplaceApp() {
    val navController = rememberNavController()
    
    NavHost(
        navController = navController,
        startDestination = "welcome"
    ) {
        //auth screens
        composable("welcome") {
            WelcomeScreen(navController)
        }
        
        composable("login") {
            LoginScreen(navController)
        }
        
        composable("register") {
            RegisterScreen(navController)
        }
        
        //farmer screens
        composable("farmer_dashboard") {
            FarmerDashboardScreen(navController)
        }
        
        composable("add_product") {
            AddProductScreen(navController)
        }
        
        composable("my_products") {
            MyProductsScreen(navController)
        }
        
        //buyer screens
        composable("buyer_home") {
            BuyerHomeScreen(navController)
        }
        
        composable("home") {
            BuyerHomeScreen(navController)
        }
        
        composable(
            route = "product_details/{productId}",
            arguments = listOf(
                navArgument("productId") {
                    type = NavType.StringType
                }
            )
        ) { backStackEntry ->
            val productId = backStackEntry.arguments?.getString("productId") ?: ""
            ProductDetailsScreen(navController, productId)
        }
        
        //common screens
        composable("support") {
            SupportScreen(navController)
        }
        
        composable("profile") {
            ProfileScreen(navController)
        }
        
        composable("settings") {
            SettingsScreen(navController)
        }
    }
}