package com.example.fmplace.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.navigation.NavController
import com.example.fmplace.firebase.AuthRepository
import com.example.fmplace.model.AppLanguage
import com.example.fmplace.model.User
import com.example.fmplace.utils.LanguageManager
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(navController: NavController) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val authRepository = remember { AuthRepository() }
    
    //get current language from languageManager
    var selectedLanguage by remember { mutableStateOf(AppLanguage.fromCode(LanguageManager.getSavedLanguage(context))) }
    var expanded by remember { mutableStateOf(false) }
    
    //function to handle language change
    fun changeLanguage(language: AppLanguage) {
        selectedLanguage = language
        expanded = false
        
        //change app language
        LanguageManager.setAppLanguage(context, language.code)
        
        //restart the app to apply language changes
        context.packageManager.getLaunchIntentForPackage(context.packageName)?.let { intent ->
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }
        
        //update user's language preference
        coroutineScope.launch {
            val currentUser = authRepository.getCurrentUser()
            if (currentUser != null) {
                val result = authRepository.getUserData(currentUser.uid)
                if (result.isSuccess) {
                    val user = result.getOrNull()
                    if (user != null) {
                        val updatedUser = user.copy(language = language.code)
                        authRepository.updateUserData(currentUser.uid, updatedUser)
                    }
                }
            }
        }
    }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // language selection
        Text(
            text = "Language / भाषा",
            style = MaterialTheme.typography.titleMedium
        )
        
        // language dropdown
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = selectedLanguage.displayName,
                style = MaterialTheme.typography.bodyLarge
            )
            
            ExposedDropdownMenuBox(
                expanded = expanded,
                onExpandedChange = { expanded = it }
            ) {
                OutlinedTextField(
                    value = selectedLanguage.displayName,
                    onValueChange = {},
                    readOnly = true,
                    modifier = Modifier.menuAnchor()
                )
                
                ExposedDropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    AppLanguage.values().forEach { language ->
                        DropdownMenuItem(
                            text = { Text(language.displayName) },
                            onClick = { changeLanguage(language) }
                        )
                    }
                }
            }
        }
        
        //firebase console button

        Button(
            onClick = {
                val firebaseUrl = Uri.parse("https://console.firebase.google.com")
                context.startActivity(Intent(Intent.ACTION_VIEW, firebaseUrl))
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Open Firebase Console")
        }

        //cloudinary dashboard button

        Button(
            onClick = {
                val cloudinaryUrl = Uri.parse("https://cloudinary.com/console")
                context.startActivity(Intent(Intent.ACTION_VIEW, cloudinaryUrl))
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Open Cloudinary Dashboard")
        }
    }
}
