# Open Firebase Console
Start-Process "https://console.firebase.google.com"

# Wait a moment before opening Cloudinary
Start-Sleep -Seconds 2

# Open Cloudinary Console
Start-Process "https://cloudinary.com/console"

Write-Host "Dashboards will open in your default browser..."
