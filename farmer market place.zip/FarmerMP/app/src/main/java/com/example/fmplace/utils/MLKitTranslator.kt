package com.example.fmplace.utils

import android.content.Context
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.nl.translate.Translation

object MLKitTranslator {
    private val translatorCache = mutableMapOf<String, Translator>()

    fun getTranslator(sourceLang: String, targetLang: String): Translator {
        val key = "$sourceLang-$targetLang"
        return translatorCache.getOrPut(key) {
            val options = TranslatorOptions.Builder()
                .setSourceLanguage(sourceLang)
                .setTargetLanguage(targetLang)
                .build()
            Translation.getClient(options)
        }
    }

    fun translate(
        context: Context,
        text: String,
        sourceLang: String,
        targetLang: String,
        onSuccess: (String) -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        val translator = getTranslator(sourceLang, targetLang)
        translator.downloadModelIfNeeded()
            .addOnSuccessListener {
                translator.translate(text)
                    .addOnSuccessListener { translatedText ->
                        onSuccess(translatedText)
                    }
                    .addOnFailureListener { e ->
                        onFailure(e)
                    }
            }
            .addOnFailureListener { e ->
                onFailure(e)
            }
    }

    fun getMLKitLangCode(appLangCode: String): String {
        return when (appLangCode) {
            "en" -> TranslateLanguage.ENGLISH
            "mr" -> TranslateLanguage.MARATHI
            "hi" -> TranslateLanguage.HINDI
            else -> TranslateLanguage.ENGLISH
        }
    }
}
