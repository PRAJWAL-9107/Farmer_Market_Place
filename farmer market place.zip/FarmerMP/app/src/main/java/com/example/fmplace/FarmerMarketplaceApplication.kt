package com.example.fmplace

import android.app.Application
import com.example.fmplace.firebase.FirebaseManager
import com.example.fmplace.storage.CloudinaryRepository
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import com.example.fmplace.utils.LanguageManager
import dagger.hilt.android.HiltAndroidApp

/**
 * Application class for the Farmer Marketplace app
 * Initializes Firebase and other app-wide components
 */
@HiltAndroidApp
class FarmerMarketplaceApplication : Application() {
    
    override fun onCreate() {
        super.onCreate()
        
        // Apply saved locale via AppCompat per-app locales
        val saved = LanguageManager.getSavedLanguage(this)
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(saved))
        
        // Initialize Firebase
        FirebaseManager.initialize(this)
        
        // Initialize Cloudinary
        CloudinaryRepository.init(this)
    }
}
