package com.example.fmplace.model

enum class AppLanguage(val code: String, val displayName: String, val flag: String) {
    ENGLISH("en", "English", "🇬🇧"),
    MARATHI("mr", "मराठी", "🇮🇳"),
    HINDI("hi", "हिंदी", "🇮🇳");

    companion object {
        fun fromCode(code: String): AppLanguage {
            return values().find { it.code == code } ?: ENGLISH
        }

        fun fromDisplayName(displayName: String): AppLanguage {
            return values().find { it.displayName == displayName } ?: ENGLISH
        }
    }
}
