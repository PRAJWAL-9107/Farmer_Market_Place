package com.example.fmplace.utils

import android.content.Context
import android.util.Log
import android.widget.Toast
import com.example.fmplace.firebase.FirebaseManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/**
 * Utility class to test Firestore connection
 */
object FirestoreTest {
    private const val TAG = "FirestoreTest"
    
    /**
     * Test Firestore connection by writing and reading a test document
     * This function should be called from a coroutine scope
     */
    suspend fun testConnection(context: Context): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val db = FirebaseManager.firestore
                val testCollection = db.collection("test")
                val testDocument = testCollection.document("test_connection")
                
                // Write test data
                val testData = hashMapOf(
                    "timestamp" to System.currentTimeMillis(),
                    "message" to "Firestore connection test"
                )
                
                Log.d(TAG, "Writing test data to Firestore...")
                testDocument.set(testData).await()
                Log.d(TAG, "Successfully wrote test data to Firestore")
                
                // Read test data
                Log.d(TAG, "Reading test data from Firestore...")
                val snapshot = testDocument.get().await()
                Log.d(TAG, "Successfully read test data from Firestore: ${snapshot.data}")
                
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Firestore connection successful!", Toast.LENGTH_SHORT).show()
                }
                
                true
            } catch (e: Exception) {
                Log.e(TAG, "Error testing Firestore connection", e)
                
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        context, 
                        "Firestore connection failed: ${e.message}", 
                        Toast.LENGTH_LONG
                    ).show()
                }
                
                false
            }
        }
    }
}
