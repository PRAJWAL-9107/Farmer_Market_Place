package com.example.fmplace.firebase

import android.util.Log
import com.example.fmplace.model.Product
import com.example.fmplace.model.ProductCategory
import com.example.fmplace.firebase.FirebaseManager
import kotlinx.coroutines.tasks.await

/**
 * Repository class for Firebase Firestore operations related to products
 */
class ProductRepository {
    private val db = FirebaseManager.firestore
    private val productsCollection = db.collection("products")
    
    /**
     * Add a new product to Firestore
     */
    suspend fun addProduct(product: Product): Result<String> {
        return try {
            val documentRef = productsCollection.document()
            val productWithId = product.copy(id = documentRef.id)
            
            documentRef.set(productWithId.toMap()).await()
            Result.success(documentRef.id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * Get all products by a specific user (farmer)
     */
    suspend fun getProductsByUser(userId: String): Result<List<Product>> {
        return try {
            val querySnapshot = productsCollection
                .whereEqualTo("sellerId", userId)
                .get()
                .await()
                
            val products = querySnapshot.documents.mapNotNull { document ->
                document.data?.let { data ->
                    val map = data as Map<String, Any>
                    try {
                        Product.fromMap(map)
                    } catch (e: Exception) {
                        Log.e("ProductRepository", "Error converting document to Product: ${e.message}")
                        null
                    }
                } ?: Product()
            }
            
            Result.success(products)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * Get all products
     */
    suspend fun getAllProducts(): Result<List<Product>> {
        return try {
            val querySnapshot = productsCollection.get().await()
            val products = querySnapshot.documents.mapNotNull { document ->
                document.data?.let { data ->
                    val map = data as Map<String, Any>
                    try {
                        Product.fromMap(map)
                    } catch (e: Exception) {
                        Log.e("ProductRepository", "Error converting document to Product: ${e.message}")
                        null
                    }
                } ?: Product()
            }
            
            Result.success(products)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * Get products by category
     */
    suspend fun getProductsByCategory(category: ProductCategory): Result<List<Product>> {
        return try {
            println("Fetching products for category: ${category.name}")
            
            // Get all products first
            val querySnapshot = productsCollection.get().await()
            
            // Filter locally to ensure enum comparison works correctly
            val products = querySnapshot.documents.mapNotNull { document ->
                document.data?.let { data ->
                    val map = data as Map<String, Any>
                    try {
                        Product.fromMap(map)
                    } catch (e: Exception) {
                        Log.e("ProductRepository", "Error converting document to Product: ${e.message}")
                        null
                    }
                } ?: Product()
            }.filter { product ->
                println("Product: ${product.name}, Category: ${product.category.name}")
                product.category == category
            }
            
            println("Found ${products.size} products in category ${category.name}")
            Result.success(products)
        } catch (e: Exception) {
            println("Error fetching products by category: ${e.message}")
            Result.failure(e)
        }
    }
    
    /**
     * Update an existing product
     */
    suspend fun updateProduct(product: Product): Result<Unit> {
        return try {
            productsCollection.document(product.id).set(product.toMap()).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * Delete a product
     */
    suspend fun deleteProduct(productId: String): Result<Unit> {
        return try {
            productsCollection.document(productId).delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
