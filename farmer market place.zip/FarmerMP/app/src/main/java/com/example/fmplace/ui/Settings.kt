package com.example.fmplace.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavController
import com.example.fmplace.firebase.AuthRepository
import com.example.fmplace.model.AppLanguage
import com.example.fmplace.model.User
import com.example.fmplace.utils.LanguageManager
import com.example.fmplace.utils.LocalizationHelper
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import com.example.fmplace.R

// TODO: Fix: All usages of SettingsScreen must provide firebaseAuth and db as arguments.
// Example:
// SettingsScreen(navController, FirebaseAuth.getInstance(), FirebaseFirestore.getInstance())

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(navController: NavController, firebaseAuth: FirebaseAuth, db: FirebaseFirestore) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val authRepository = remember { AuthRepository(
        firebaseAuth = firebaseAuth,
        db = db
    ) }
    
    //get current language from languageManager
    var selectedLanguage by remember { mutableStateOf(AppLanguage.fromCode(LanguageManager.getSavedLanguage(context))) }
    var expanded by remember { mutableStateOf(false) }
    
    // map language enum to resource IDs
    val languageLabelMap = mapOf(
        AppLanguage.ENGLISH to R.string.english,
        AppLanguage.MARATHI to R.string.marathi,
        AppLanguage.HINDI to R.string.hindi
    )
    
    //function to handle language change
    fun changeLanguage(language: AppLanguage) {
        selectedLanguage = language
        expanded = false
        
        //change app language
        LanguageManager.setAppLanguage(context, language.code)
        // prompt user to select keyboard for new language
        LocalizationHelper.promptKeyboardPicker(context)
        
        //update user's language preference
        coroutineScope.launch {
            val currentUser = firebaseAuth.currentUser
            if (currentUser != null) {
                val result = authRepository.getUserData(currentUser.uid)
                if (result.isSuccess) {
                    val user = result.getOrNull()
                    if (user != null) {
                        val updatedUser = user.copy(language = language.code)
                        authRepository.updateUserData(currentUser.uid, updatedUser)
                    }
                }
            }
        }
        // Force activity recreate for language change to take effect everywhere
        (context as? Activity)?.recreate()
    }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // language selection
        Text(
            text = stringResource(R.string.language),
            style = MaterialTheme.typography.titleMedium
        )
        
        // language dropdown
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = stringResource(languageLabelMap[selectedLanguage]!!),
                style = MaterialTheme.typography.bodyLarge
            )
            
            ExposedDropdownMenuBox(
                expanded = expanded,
                onExpandedChange = { expanded = it }
            ) {
                OutlinedTextField(
                    value = stringResource(languageLabelMap[selectedLanguage]!!),
                    onValueChange = {},
                    readOnly = true,
                    modifier = Modifier.menuAnchor()
                )
                
                ExposedDropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    AppLanguage.values().forEach { language ->
                        DropdownMenuItem(
                            text = { Text(stringResource(languageLabelMap[language]!!)) },
                            onClick = { changeLanguage(language) }
                        )
                    }
                }
            }
        }
        
        //firebase console button

        Button(
            onClick = {
                val firebaseUrl = Uri.parse("https://console.firebase.google.com")
                context.startActivity(Intent(Intent.ACTION_VIEW, firebaseUrl))
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(stringResource(R.string.open_firebase_console))
        }

        //cloudinary dashboard button

        Button(
            onClick = {
                val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse("mailto:jadhav9107@gmail.com")
                }
                context.startActivity(emailIntent)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(stringResource(R.string.contact_support))
        }
    }
}

// Usage in previews or other calls must pass firebaseAuth and db
// Example for preview:
//@Preview
//@Composable
//fun PreviewSettingsScreen() {
//    SettingsScreen(
//        navController = rememberNavController(),
//        firebaseAuth = FirebaseAuth.getInstance(),
//        db = FirebaseFirestore.getInstance()
//    )
//}
