package com.example.fmplace.utils

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

object LanguageManager {
    private const val PREFS_NAME = "app_prefs"
    private const val KEY_LANGUAGE = "language_code"

    private fun getSharedPreferences(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun setAppLanguage(context: Context, languageCode: String) {
        // Persist new language
        getSharedPreferences(context)
            .edit()
            .putString(KEY_LANGUAGE, languageCode)
            .apply()
        // Apply per-app locale
        val locales = LocaleListCompat.forLanguageTags(languageCode)
        AppCompatDelegate.setApplicationLocales(locales)
    }

    fun getSavedLanguage(context: Context): String {
        return getSharedPreferences(context)
            .getString(KEY_LANGUAGE, "en") ?: "en"
    }

    fun getLanguageDisplayName(code: String): String {
        return when (code) {
            "mr" -> "मराठी"
            "hi" -> "हिंदी"
            "en" -> "English"
            else -> "English"
        }
    }

    fun getLanguageCodeFromDisplayName(displayName: String): String {
        return when (displayName) {
            "मराठी" -> "mr"
            "हिंदी" -> "hi"
            "English" -> "en"
            else -> "en"
        }
    }
}
