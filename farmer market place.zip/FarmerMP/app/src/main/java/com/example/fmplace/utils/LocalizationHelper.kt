package com.example.fmplace.utils

import android.content.Context
import android.content.res.Configuration
import android.content.res.Resources
import android.view.inputmethod.InputMethodManager
import java.util.Locale

object LocalizationHelper {
    /**
     * Returns a Context with updated locale configuration.
     */
    fun setLocale(context: Context, languageCode: String): Context {
        val locale = Locale(languageCode)
        Locale.setDefault(locale)

        val resources: Resources = context.resources
        val config = Configuration(resources.configuration)
        config.setLocale(locale)

        return context.createConfigurationContext(config)
    }

    /**
     * Shows the input method picker so user can manually select keyboard language.
     */
    fun promptKeyboardPicker(context: Context) {
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showInputMethodPicker()
    }
}
